## OpenEuler 安装

实验环境使用 OpenEuler-22.03-LTS 版本。

### OpenEuler 系统内核版本

OpenEuler 系统内核版本

- OpenEuler-24.03-LTS 内核版本为：6.6.0-28.0.0.34.oe2403.x86_64。
- OpenEuler-22.03-LTS 内核版本为：5.10.0-60.18.0.50.oe2203.x86_64。
- OpenEuler-20.03-LTS 内核版本为：4.19.90-2003.4.0.0036.oe1.x86_64。

使用 VMWare workstation 安装 OpenEuler系统是系统选择：

- 安装 OpenEuler-24.03-LTS 系统时，系统选择`其他 Linux 6.x 内核 64 位`。

- 安装 OpenEuler-22.03-LTS 系统时，系统选择`其他 Linux 5.x 内核 64 位`。

- 安装 OpenEuler-20.03-LTS 系统时，系统选择`其他 Linux 4.x 内核 64 位`。

### OpenEuler 安装过程

参考 rocky 安装过程。

### OpenEuler 基本配置

```bash
# 配置 bash 补全和vim
[root@OpenEuler2203 ~]# yum install -y bash-completion vim

# 关闭 SELinux
[root@OpenEuler2203 ~]# sed -ri 's/^SELINUX=.*/SELINUX=disabled/g' /etc/selinux/config

# 关闭防火墙
[root@OpenEuler2203 ~]# systemctl disable firewalld --now

# OpenEuler仓库有时候比较慢，换成华为云
[root@OpenEuler2203 ~]# sed -i \
's@http://repo.OpenEuler.org/@https://repo.huaweicloud.com/OpenEuler/@g' \
/etc/yum.repos.d/OpenEuler.repo
```



### OpenEuler 安装图形界面

主流的Linux桌面管理套件有：

1. GNOME 桌面是Linux系统的最流行的桌面环境之一， 它有一个内置的虚拟桌面管理器。它可以通过ubuntu、 fedora和SUSE等系统进行安装。GNOME的虚拟桌面管理器使用户可以轻松地创建、删除、重命名和移动虚拟桌面。它还可以使用户更改屏幕分辨率和设置对齐方式。
2. KDE 桌面是另一个流行的桌面环境，它也有个内置的虚拟桌面管理器。 KDE的虚拟桌面可以轻松地添加、 删除、重命名和移动。它还提供了几种预定义布局，这些布局针对不同的使用方式提供了优化。
3. XFCE 桌面是一个轻量级的桌面环境，它也有一个内置的虛拟桌面管理器。XFCE的虚拟桌面管理器让用户可以轻松地添加、删除、重命名和移动虚拟桌面。此外，XFCE还提供了一个布局选项，可以将I作空间合并为一个虚拟桌面。
4. LXDE 桌面是另一个轻量级的桌面环境，它也有一个内置的虚拟桌面管理器。LXDE的虚拟桌面可以让用户轻松地添加、删除、重命名和移动虚拟桌面。此外，LXDE还提供了一个帮助用户更改屏幕分辨率和设置墙纸的选项。

**国内的Linux发型版本使用不同的桌面套件，例如ukui。**



#### 部署 GNOME 桌面

效果如下：

<img src="OpenEuler安装.images/image-20230712123301949.png" alt="image-20230712123301949" style="zoom:80%;" /> 

部署过程如下：

```bash
# 使用默认仓库即可

# 2203 版本
[root@OpenEuler2203 ~]# yum groupinstall -y GNOME

# 2403 版本
[root@OpenEuler2203 ~]# yum install -y gdm

# 安装图形化fonts
[root@OpenEuler2203 ~]# yum groupinstall -y fonts

# 设置默认图形化启动系统
[root@OpenEuler2203 ~]# systemctl set-default graphical.target

# 启动图形化
[root@OpenEuler2203 ~]# systemctl isolate graphical.target
```



#### 部署 ukui 桌面

2020年10月9日优麒麟开源操作系统正式发布 UKUI for OpenEuler 。

UKUI 是由麒麟团队开发的基于 Linux 发行版的轻量级桌面环境，默认搭载在优麒麟开源操作系统和银河麒麟 / 中标麒麟商业发行版中。

效果如下：

![image-20230712122029427](OpenEuler安装.images/image-20230712122029427.png)

> 其实 从 OpenEuler-20.03-LTS-SP1 已经集成了UKUI 2.0。

UKUI桌面需要的软件包不在iso镜像中，需要从公网获取。

部署过程如下：

```bash
# 准备OpenEuler仓库
[root@OpenEuler2203 ~]# yum install -y OpenEuler-repos

[root@OpenEuler2203 ~]# cd /etc/yum.repos.d/
[root@OpenEuler2203 yum.repos.d]# mv OpenEuler-dvd.repo ~
[root@OpenEuler2203 yum.repos.d]# mv OpenEuler.repo.bak OpenEuler.repo
[root@OpenEuler2203 yum.repos.d]# cd

# 安装图形化ukui
[root@OpenEuler2203 ~]# yum install -y ukui

# 设置默认图形化启动系统
[root@OpenEuler2203 ~]# systemctl set-default graphical.target

# 启动图形化
[root@OpenEuler2203 ~]# systemctl isolate graphical.target
```



#### 桌面主题切换

选择用户

<img src="OpenEuler安装.images/image-20230712122218201.png" alt="image-20230712122218201" style="zoom:80%;" /> 

输入密码前，桌面管理器类型。

<img src="OpenEuler安装.images/image-20230712122137614.png" alt="image-20230712122137614" style="zoom:80%;" /> 

#### 部署 xfce 桌面

XFCE是一个基于GTK+的轻量级桌面环境，专为在性能和效率方面有较高要求的用户设计，特别适用于资源有限的设备和老旧硬件。

XFCE具有简洁的设计、快速的响应速度以及低内存占用等特点，因此受到了许多用户的赞誉。用户可以根据个人喜好更改主题、图标、窗口管理器、面板布局等设置，以满足不同的需求。此外，XFCE还提供了丰富的配置选项，使用户能够轻松地定制桌面的外观和行为。

在稳定性和兼容性方面，XFCE也表现出色。它能够在多种Linux发行版上稳定运行，包括Ubuntu、Fedora、Debian、Arch Linux等。这使得用户可以在不同的操作系统上享受到XFCE桌面带来的便利和舒适体验。

与其他大型桌面环境相比，XFCE具有更高的运行效率和更低的资源占用。这使得它成为老旧硬件和资源有限设备的理想选择。同时，XFCE还提供了良好的多显示器支持，使用户能够轻松地在多个显示器之间切换和工作。

效果如下：

<img src="OpenEuler安装.images/image-20240315085203315.png" alt="image-20240315085203315" style="zoom:80%;" /> 

登录后如下：

<img src="OpenEuler安装.images/image-20240315085322189.png" alt="image-20240315085322189" style="zoom:80%;" /> 



下面命令是在最小化安装系统的情况下安装XFCE：

```bash
# 使用系统默认仓库件（配置Everything源，EPOL源）

# 安装字库
[root@OpenEuler2203 ~]# dnf install -y dejavu-fonts liberation-fonts gnu-*-fonts google-*-fonts

# 安装Xorg
[root@OpenEuler2203 ~]# dnf install -y xorg-*

# 安装XFCE及组件
[root@OpenEuler2203 ~]# dnf install -y xfwm4 xfdesktop xfce4-* xfce4-*-plugin network-manager-applet *fonts

# 安装登录管理器
[root@OpenEuler2203 ~]# dnf install -y lightdm lightdm-gtk

# 设置默认桌面为XFCE 通过root权限用户设置
[root@OpenEuler2203 ~]# echo 'user-session=xfce' >> /etc/lightdm/lightdm.conf.d/60-lightdm-gtk-greeter.conf

# 使用登录管理器登录XFCE
[root@OpenEuler2203 ~]# systemctl start lightdm

# 登录管理器启动后，在右上角左侧选择"xfce-session"，输入用户名、密码登录。

# 设置开机自启动图形界面
[root@OpenEuler2203 ~]# systemctl enable lightdm
[root@OpenEuler2203 ~]# systemctl set-default graphical.target

# 如果默认安装了gdm，建议停用gdm
[root@OpenEuler2203 ~]# systemctl disable gdm

# 重启验证
[root@OpenEuler2203 ~]# reboot
```

##### 故障

Q1: 为什么 lightdm 登录界面背景是黑色的？

A1:  登录界面是黑色的是因为 lightdm-gtk 默认配置文件 /etc/lightdm/lightdm-gtk-greeter.conf 中没有设置 background。 可以在该配置文件最后的[greeter]段中设置 background=/usr/share/backgrounds/xfce/xfce-blue.jpg 然后使用“systemctl restart lightdm”命令就可以看到背景了。
